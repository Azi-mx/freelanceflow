export const required = {
  SALT_ROUNDS: 12,
} as const;
