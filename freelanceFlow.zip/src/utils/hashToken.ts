import bcrypt from "bcryptjs";
import { required } from "../constants.js";
export const hashToken = async (token: string): Promise<string> => {
  return await bcrypt.hash(token, required.SALT_ROUNDS);
};
